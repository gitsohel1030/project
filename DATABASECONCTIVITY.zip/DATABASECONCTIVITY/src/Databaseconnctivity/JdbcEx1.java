package Databaseconnctivity;
import java.sql.*;

public class JdbcEx1 {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","Anju@1234");
				 Statement st=con.createStatement();
				 try{
				  ResultSet rs= st.executeQuery("select *from student");
				  while(rs.next());
				  
				  
	}
				 catch(Exception e) {
					 System.out.println(e);
				 }

}
}
